from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from My_App.models import *


def login(request):
    return render(request,'login user.html')

def login_post(request):
    username=request.POST['textfield']
    password=request.POST['textfield2']
    try:
        user=Login.objects.get(username=username,password=password)
        request.session['lid']=user.id
        if user.type=='admin':
            return HttpResponse('''<script>alert("logined");window.location='/admin_home'</script>''')
        elif user.type == 'owner':
            return HttpResponse('''<script>alert("logined");window.location='/home'</script>''')
        else:
            return HttpResponse('''<script>alert("invalid.........");window.location='/'</script>''')

    except:
        return HttpResponse('''<script>alert("invalid..");window.location='/'</script>''')
def admin_home(request):
    return render(request,'admin/admin homepage.html')

def view_route(request):
    ob=Route.objects.all()
    return render(request,'admin/add route.html',{'data':ob})

def add_route(request):

    return render(request,'admin/add route 2.html')

def add_route_post(request):
    fromplace=request.POST['textfield']
    toplace=request.POST['textfield2']

    route=Route()
    route.from_place=fromplace
    route.to_place=toplace
    route.save()
    return HttpResponse('''<script>alert("successfully saved");window.location='/view_route'</script>''')

def delete_route(request,id):
    request.session['rid']=id
    ob=Route.objects.get(id=request.session['rid'])
    ob.delete()
    return HttpResponse('''<script>alert("deleted successfully");window.location='/view_route'</script>''')






def admin_add_stops(request):
    a=Route.objects.all()
    return render(request,'admin/add stops.html',{'data':a})



def admin_add_stops_post(request):
    route=request.POST['route']
    stop=request.POST['stop']
    a=Stop()
    a.stop_name=stop
    a.ROUTE=Route.objects.get(id=route)
    a.save()
    return HttpResponse('''<script>alert(" successfully");window.location='/admin_add_stops'</script>''')





def mng_stop(request,id):
    request.session['rid'] = id
    ob = Stop.objects.filter(ROUTE_id=request.session['rid']).order_by('-id')
    return render(request,'admin/add stop.html',{'data':ob})


def delete_stop(request,id):
    request.session['rid']=id
    ob = Stop.objects.get(id=request.session['rid'])
    ob.delete()
    return HttpResponse('''<script>alert("stop deleted successfully");window.location='/view_stop'</script>''')

def accept_bus(request,id):
    a=Bus.objects.filter(id=id).update(status='accept')
    return HttpResponse('''<script>alert("Accepted");window.location='/admin_home'</script>''')

def reject_bus(request,id):
    a = Bus.objects.filter(id=id).update(status='reject')
    return HttpResponse('''<script>alert("rejected");window.location='/admin_home'</script>''')


def add_routestop(request,id):
    ob = Route.objects.get(id=id)
    return render(request, 'admin/add stop 2.html',{'data':ob})


def add_routestop_post(request):
    id=request.POST['id']
    stop_name=request.POST['textfield']
    ob=Stop()
    ob.stop_name=stop_name
    ob.ROUTE=Route.objects.get(id=id)
    ob.save()
    return HttpResponse('''<script>alert("added successfully");window.location='/view_route'</script>''')



def add_time_schesule(request):
    ob=Route.objects.all()
    b=Bus.objects.all()
    return render(request,'admin/add time schedule.html',{"route":ob,"bus":b})

def submit_schedule(request):
    route=request.POST['route']
    bus=request.POST['bus']
    stime= request.POST['stime']
    etime = request.POST['etime']
    trip=request.POST['trip']
    busname=request.POST['busname']
    ob=Time()
    ob.routename=Route.objects.get(id=route)
    ob.BUS=Bus.objects.get(id=bus)
    ob.starttime=stime
    ob.endtime=etime
    ob.tripname=trip
    ob.busname=busname
    ob.save()
    return HttpResponse('''<script>alert("added successfully");window.location='/view_schedule'</script>''')





def view_schedule(request):
    # ob=Time.objects.all(id=id)
    ob=Time.objects.all()
    kk=Route.objects.all()

    return render(request, 'admin/view schedule.html',{'data':ob,'route':kk})

def view_schedule_search(request):
    route=request.POST['route']
    ob=Time.objects.filter(routename__id=route)
    kk = Route.objects.all()
    return render(request, 'admin/view schedule.html',{'data':ob,'route':kk})

def dlt_schedule(request,id):

    ob = Time.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("deleted successfully");window.location='/view_schedule'</script>''')




def verify_bus(request):
    ob=Bus.objects.all()
    return render(request, 'admin/verify bus.html',{'data':ob})

def view_stop(request):
    a=Stop.objects.all()
    return render(request, 'admin/all stop.html',{'data':a})


def edit_stops(request):
    ob = Stop.objects.all()
    return render(request, 'admin/edit'
                           ' stops.html', {'data': a})


# def edit_stops_post(request):
    # stop_name=request.POST['textfield']
    # ROUTE=request.POST['route']


def add_stop(request):
    return render(request, 'admin/all stop 2.html')

def route_edit(request,id):
    request.session['rid'] = id
    ob = Route.objects.get(id=request.session['rid'])
    return render(request, 'admin/route edit.html',{'val':ob})

def route_edit_post(request):
    from_place=request.POST['textfield']
    to_place=request.POST['textfield2']

    ob=Route.objects.get(id=request.session['rid'])
    ob.from_place=from_place
    ob.to_place=to_place
    ob.save()
    return HttpResponse('''<script>alert("edited successfully");window.location='/view_route'</script>''')

#owner------------------

def bus_form(request):
    return render(request, 'owner/bus form.html')

def bus_owner(request):
    return render(request, 'owner/bus owner.html')

def own_reg(request):
    return render(request, 'owner/own reg.html')


def own_details(request):
    try:
        name=request.POST['textfield']
        place=request.POST['textfield2']
        password=request.POST['textfield3']
        pin=request.POST['textfield4']
        email=request.POST['textfield5']
        phone=request.POST['textfield6']
        username=request.POST['textfield7']
        image=request.FILES['file']
        cp=request.POST['textfield9']
        fs=FileSystemStorage()
        fn=fs.save(image.name,image)
        if password == cp:
            ob1=Login()
            ob1.username=username
            ob1.password=password
            ob1.type='owner'
            ob1.save()
            ob=Owner()
            ob.LOGIN=ob1
            ob.name=name
            ob.place=place
            ob.pin=pin
            ob.email=email
            ob.phone=phone
            ob.image=fn
            ob.save()
            return HttpResponse('''<script>alert("added successfully");window.location='/'</script>''')
        else:
            return HttpResponse('''<script>alert("Invalid Password");window.location='/own_reg'</script>''')
    except:
        return HttpResponse('''<script>alert("Fill out all fields");window.location='/own_reg'</script>''')


def home(request):
    return render(request, 'owner/owner homepage.html')

def reg_bus(request):
    ob=Bus.objects.filter(OWNER__LOGIN__id=request.session['lid'])
    return render(request, 'owner/Reg bus.html',{"data":ob})

def reg_bus2(request):
    return render(request, 'owner/reg bus2.html')

def reg_bus2post(request):
    name=request.POST['textfield']
    bus_no=request.POST['textfield2']
    model=request.POST['textfield3']
    year=request.POST['textfield4']
    certificates=request.FILES['file']
    ob=Bus()
    ob.OWNER=Owner.objects.get(LOGIN__id=request.session['lid'])
    ob.name=name
    ob.bus_no=bus_no
    ob.model=model
    ob.year=year
    ob.certificate=certificates
    ob.save()
    return HttpResponse('''<script>alert("added successfully");window.location='/reg_bus.html'</script>''')


    return render(request, 'owner/reg bus2.html')

    return HttpResponse('''<script>alert("added successfully");window.location='/reg_bus.html'</script>''')


def staff_mng2(request):
    a=Bus.objects.all()
    return render(request, 'owner/staff mngement 2.html',{'data':a})

def staff_mng2post(request):
     name=request.POST['textfield']
     ph_no= request.POST['textfield2']
     email= request.POST['textfield3']
     image=request.FILES['file']
     role= request.POST['select']
     bus=request.POST['select2']
     username=request.POST['textfield4']
     password=request.POST['textfield5']
     ob=Staff()
     ob.name=name
     ob.ph_no=ph_no
     ob.email=email
     ob.image=image
     ob.role=role
     ob.busname=Bus.objects.get(id=bus)
     ob.username=username
     ob.password=password
     ob.save()
     return HttpResponse('''<script>alert("added successfully");window.location='/staff_mng.html'</script>''')


def staff_mng(request):
    return render(request, 'owner/Staff_Management.html')

def ow_view_schedule(request):
    # ob=Time.objects.all(id=id)
    ob=Time.objects.all()
    kk=Route.objects.all()

    return render(request, 'owner/view schedule.html',{'data':ob,'route':kk})



def ow_view_schedule_search(request):
    route=request.POST['route']
    ob=Time.objects.filter(routename__id=route)
    kk = Route.objects.all()
    return render(request, 'owner/view schedule.html',{'data':ob,'route':kk})

