from django.db import models

# Create your models here.
class Login(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    type = models.CharField(max_length=15)

class Owner(models.Model):
    LOGIN = models.ForeignKey(Login,on_delete=models.CASCADE)
    name = models.CharField(max_length=40)
    place = models.CharField(max_length=40)
    pin = models.IntegerField()
    email = models.CharField(max_length=40)
    phone = models.BigIntegerField()
    image = models.FileField()

class Route(models.Model):
    from_place = models.CharField(max_length=40)
    to_place = models.CharField(max_length=40)

class Stop(models.Model):
    stop_name = models.CharField(max_length=40)
    ROUTE = models.ForeignKey(Route,on_delete=models.CASCADE)

class Bus(models.Model):
    OWNER = models.ForeignKey(Owner,on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    bus_no = models.BigIntegerField()
    model = models.CharField(max_length=50)
    year = models.IntegerField()
    certificate = models.FileField()
    status = models.CharField(max_length=50)

class Time(models.Model):
    BUS = models.ForeignKey(Bus,on_delete=models.CASCADE)
    routename = models.ForeignKey(Route,on_delete=models.CASCADE)
    busname = models.CharField(max_length=50)
    starttime = models.CharField(max_length=50)
    endtime = models.CharField(max_length=50)
    tripname = models.CharField(max_length=50)


class Staff(models.Model):
    OWNER = models.ForeignKey(Owner,on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=40)
    phone = models.BigIntegerField()
    image = models.FileField()
    role = models.CharField(max_length=50)
    busname=models.ForeignKey(Bus,on_delete=models.CASCADE)
    LOGIN = models.ForeignKey(Login,on_delete=models.CASCADE)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

class User(models.Model):
    name = models.CharField(max_length=50)
    password = models.CharField(max_length=40)
    phone = models.BigIntegerField()
    LOGIN = models.ForeignKey(Login,on_delete=models.CASCADE)
    image = models.FileField()

class Feedback(models.Model):
    USER = models.ForeignKey(User,on_delete=models.CASCADE)
    BUS = models.ForeignKey(Bus,on_delete=models.CASCADE)
    date = models.DateField()



