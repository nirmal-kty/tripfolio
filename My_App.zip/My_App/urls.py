from django.urls import path

from My_App import views

urlpatterns = [
    path('',views.login),
    path('login_post',views.login_post),
    path('admin_home',views.admin_home),
    path('view_route',views.view_route),

    path('admin_add_stops',views.admin_add_stops),
    path('admin_add_stops_post',views.admin_add_stops_post),

    path('edit_stops',views.edit_stops),


    path('add_route',views.add_route),
    path('mng_stop/<int:id>',views.mng_stop),
    path('add_routestop/<id>',views.add_routestop),
    path('add_time_schesule',views.add_time_schesule),
    path('view_schedule',views.view_schedule),
    path('verify_bus',views.verify_bus),
    path('view_stop',views.view_stop),
    path('add_stop',views.add_stop),
    path('route_edit/<int:id>',views.route_edit),
    path('add_route_post',views.add_route_post),
    path('delete_route/<int:id>',views.delete_route),
    path('route_edit_post',views.route_edit_post),
    path('add_routestop_post',views.add_routestop_post),
    path('delete_stop/<int:id>',views.delete_stop),
    path('accept_bus/<id>',views.accept_bus),
    path('reject_bus/<id>',views.reject_bus),

    path('submit_schedule',views.submit_schedule),
    path('view_schedule_search',views.view_schedule_search),
    path('dlt_schedule/<int:id>',views.dlt_schedule),

    #--------owner--------

    path('bus_form',views.bus_form),

    path('bus_owner',views.bus_owner),

    path('own_reg',views.own_reg),

    path('home',views.home),

    path('reg_bus',views.reg_bus),

    path('staff_mng',views.staff_mng),
    path('staff_mng2',views.staff_mng2),
    path('staff_mng2post',views.staff_mng2post),
    path('own_details',views.own_details),

    path('ow_view_schedule',views.ow_view_schedule),
    path('ow_view_schedule_search',views.ow_view_schedule_search),
    # path('reg_bus',views.reg_bus)
    path('reg_bus2',views.reg_bus2),
    path('reg_bus2post',views.reg_bus2post),



]
